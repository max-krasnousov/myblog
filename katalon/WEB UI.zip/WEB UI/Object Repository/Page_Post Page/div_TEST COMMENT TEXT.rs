<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_TEST COMMENT TEXT</name>
   <tag></tag>
   <elementGuidId>bace14a9-d3b2-4c1c-935c-6e3ab2b00a82</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = '
                                
                                    
                                    
                                        TEST COMMENT TEXT
                                    
                                
                            ' or . = '
                                
                                    
                                    
                                        TEST COMMENT TEXT
                                    
                                
                            ')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='(Posted: 2023/06/08 15:18:34)'])[1]/following::div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>45f3bba6-4522-4178-b376-6a58ce91e0d4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>panel-body</value>
      <webElementGuid>445e34c3-e05c-4e31-a315-6e3cd5e18068</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                
                                    
                                    
                                        TEST COMMENT TEXT
                                    
                                
                            </value>
      <webElementGuid>463ec814-ee0d-41bd-8615-7c6a3ed51dde</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;container-fluid&quot;]/div[@class=&quot;row content my-c&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12 col-sm-8 col-sm-offset-2&quot;]/div[@class=&quot;panel panel-default&quot;]/div[@class=&quot;panel-body&quot;]</value>
      <webElementGuid>f5d50c30-2368-446d-9431-15f10d6f66d5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(Posted: 2023/06/08 15:18:34)'])[1]/following::div[2]</value>
      <webElementGuid>b30cf2ef-99d3-4b9a-9422-718fa9dbd8c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FirstT LastT'])[2]/following::div[3]</value>
      <webElementGuid>6477e02f-48e6-4ad9-a1ac-b8038d5cd97a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reply'])[1]/preceding::div[1]</value>
      <webElementGuid>631991f6-c66f-4967-a35a-f96cfff7a9d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FirstT LastT'])[3]/preceding::div[2]</value>
      <webElementGuid>81faa132-5090-419e-8e71-e302d3343b97</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='TEST COMMENT TEXT']/parent::*</value>
      <webElementGuid>1bbba4e5-6533-435c-95b4-5dbc96b61aa6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div[2]</value>
      <webElementGuid>8b07241e-8ad9-4130-9f48-d4b2f3c78671</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                                
                                    
                                    
                                        TEST COMMENT TEXT
                                    
                                
                            ' or . = '
                                
                                    
                                    
                                        TEST COMMENT TEXT
                                    
                                
                            ')]</value>
      <webElementGuid>89258e01-5ef4-40fe-b355-a0e0bfbfcfdb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
