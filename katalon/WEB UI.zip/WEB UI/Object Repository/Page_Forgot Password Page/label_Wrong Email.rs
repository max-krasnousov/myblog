<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_Wrong Email</name>
   <tag></tag>
   <elementGuidId>35c3bf2e-1c36-488b-9107-a294a0c35dbe</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Forgot Password'])[1]/following::label[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>f4107abd-c175-4501-8376-a22605b35784</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Wrong Email!</value>
      <webElementGuid>5d40ed83-4ae0-4b0c-96e5-a4c1d0cb7730</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;container-fluid text-center&quot;]/div[@class=&quot;row content&quot;]/div[@class=&quot;col-sm-6 text-center my-login&quot;]/div[@class=&quot;alert alert-danger&quot;]/label[1]</value>
      <webElementGuid>72805396-9972-4696-86a8-d68b09c2c97f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Forgot Password'])[1]/following::label[1]</value>
      <webElementGuid>b8311ff0-cd68-4bfc-9637-cb2e7aa236a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Email:'])[1]/preceding::label[1]</value>
      <webElementGuid>ca0a2e84-c0d7-4289-b2c8-f4177f357318</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reset Password'])[1]/preceding::label[2]</value>
      <webElementGuid>bf6a1b9d-dd6b-4cf0-89e1-ebf7063a827a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Wrong Email!']/parent::*</value>
      <webElementGuid>05e643f4-d871-4007-a6f8-4bea26cb4e5a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//label</value>
      <webElementGuid>bf2b409a-a93b-4e79-8283-0259168cc9bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = 'Wrong Email!' or . = 'Wrong Email!')]</value>
      <webElementGuid>c1c10583-52f1-4ef2-8772-042eb465f7d3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
