<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Forgot password</name>
   <tag></tag>
   <elementGuidId>06ca663d-3670-441d-8bed-74e3696e16d3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.col-md-6.d-flex.justify-content-center.my-login > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@id=’forgot-pass-link’]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>4d542ec9-3df5-4470-98a6-e24f814a438e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/simple-blog/redirect/forgot-password;jsessionid=_fMHXPjLT4EM-c46XpYqta1v1Q1fOAzNYBRfwGbzO7bNQJdcvoMs!-402322966</value>
      <webElementGuid>a1d4b1c6-11f2-45cb-973b-58bd5fe82a21</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Forgot password?</value>
      <webElementGuid>53fefe3d-3634-4d82-b730-ef6a28b03418</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;container-fluid text-center&quot;]/div[@class=&quot;row content&quot;]/div[@class=&quot;col-sm-6 text-center my-login&quot;]/form[1]/div[@class=&quot;row mb-4&quot;]/div[@class=&quot;col-md-6 d-flex justify-content-center my-login&quot;]/a[1]</value>
      <webElementGuid>66028068-ba93-4374-a0fa-ab56d1ccceff</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Forgot password?')]</value>
      <webElementGuid>33c5f072-799c-4066-ba64-745ebe20ed46</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Remember me'])[1]/following::a[1]</value>
      <webElementGuid>73163b61-1698-4f2a-94a2-87a7499800d1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Password:'])[1]/following::a[1]</value>
      <webElementGuid>fe4d1d58-7a39-4cf1-add1-98b0cee782ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/preceding::a[1]</value>
      <webElementGuid>ce4c3415-d2b3-4080-bda2-f7db5be67b8b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Registration'])[1]/preceding::a[1]</value>
      <webElementGuid>5d99cf99-f3e0-44f7-ae25-02520cb772a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Forgot password?']/parent::*</value>
      <webElementGuid>9b273902-1ac2-4ef0-b474-6110292a5d2b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/simple-blog/redirect/forgot-password;jsessionid=_fMHXPjLT4EM-c46XpYqta1v1Q1fOAzNYBRfwGbzO7bNQJdcvoMs!-402322966')]</value>
      <webElementGuid>77ede97d-cde4-47c7-b5cc-bfc6698ccef8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/a</value>
      <webElementGuid>0ee699ba-3f53-4b38-b9ff-784c19515e1e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/simple-blog/redirect/forgot-password;jsessionid=_fMHXPjLT4EM-c46XpYqta1v1Q1fOAzNYBRfwGbzO7bNQJdcvoMs!-402322966' and (text() = 'Forgot password?' or . = 'Forgot password?')]</value>
      <webElementGuid>013f7698-40a0-43aa-86bf-21cd2790c49d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/simple-blog/redirect/forgot-password;jsessionid=JREHW48weQh50iyCcH3ldAITK-fYI5lbq1bRAW3Gc17mraCzQtVK!-402322966')]</value>
      <webElementGuid>44b35dd3-bc71-4172-a8b3-960f93c5bd67</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/simple-blog/redirect/forgot-password;jsessionid=JREHW48weQh50iyCcH3ldAITK-fYI5lbq1bRAW3Gc17mraCzQtVK!-402322966' and (text() = 'Forgot password?' or . = 'Forgot password?')]</value>
      <webElementGuid>1b9ad93b-958f-4a8a-aece-ae10066d5ed4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
