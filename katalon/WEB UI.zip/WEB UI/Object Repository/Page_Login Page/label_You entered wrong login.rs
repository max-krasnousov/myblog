<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_You entered wrong login</name>
   <tag></tag>
   <elementGuidId>2ac10441-ea7c-4dea-b847-361263a4b407</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Log In'])[1]/following::label[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>431b09ec-c25c-4ee6-b066-fa71e8b772d8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>You entered wrong login!</value>
      <webElementGuid>bf569109-2638-48ae-9033-5630351e54f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;container-fluid text-center&quot;]/div[@class=&quot;row content&quot;]/div[@class=&quot;col-sm-6 text-center my-login&quot;]/div[@class=&quot;alert alert-danger&quot;]/label[1]</value>
      <webElementGuid>a8a93daf-fa53-4e18-92cd-d649e5779540</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Log In'])[1]/following::label[1]</value>
      <webElementGuid>35394c18-9c5d-4d3d-a3a3-181fe9c812c1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Email:'])[1]/preceding::label[1]</value>
      <webElementGuid>ab989101-6a7d-40ca-8511-423f7de6018c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Password:'])[1]/preceding::label[2]</value>
      <webElementGuid>8b2d87bc-d2f8-402f-83a6-7695c0326212</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='You entered wrong login!']/parent::*</value>
      <webElementGuid>9903fa7f-a5fd-402c-9cd7-7fb41100ee54</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//label</value>
      <webElementGuid>add5b666-45ca-44e9-9c6f-f12bef88d891</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = 'You entered wrong login!' or . = 'You entered wrong login!')]</value>
      <webElementGuid>71734355-2e94-4215-930c-a75d2bb6e4ab</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
