<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Show more</name>
   <tag></tag>
   <elementGuidId>83ba46fc-63dc-4601-8fcd-6c0e9ededabb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Show more...')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.btn.btn-default</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>3113199d-5cc2-4827-b102-d16470617946</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/simple-blog/show/post?postId=181</value>
      <webElementGuid>0019caf8-8a56-4ece-a445-5916f1a10fe2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-default</value>
      <webElementGuid>420a6bf5-57ce-4997-b7a1-0c9248326c9c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Show more...</value>
      <webElementGuid>5aa9aec7-f1ef-4eab-a291-337ece740ab7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;container-fluid text-center&quot;]/div[@class=&quot;row content my-c&quot;]/div[@class=&quot;col-xs-8 col-xs-offset-2 text-left my&quot;]/div[@class=&quot;well&quot;]/table[@class=&quot;table table-bordered tb-my cp&quot;]/tbody[1]/tr[1]/td[@class=&quot;alert alert-info&quot;]/a[@class=&quot;btn btn-default&quot;]</value>
      <webElementGuid>8ce23ecc-856d-40ae-a9f3-5e6e14d7d8e6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Show more...')]</value>
      <webElementGuid>4a730ffb-2515-4e96-a1c7-9dc7b05a9ec3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(Posted: 2023/05/10 23:26:04)'])[1]/following::a[1]</value>
      <webElementGuid>37112124-f6ce-49a3-bdb3-cb8e72c178fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(Posted by: Test User)'])[1]/following::a[1]</value>
      <webElementGuid>59216336-f286-4314-9045-bc5fb96666e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='This is test post 1221'])[1]/preceding::a[1]</value>
      <webElementGuid>39449614-0551-41c5-97bd-5a5681e54ea6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='sdaedwqadsssssssssss'])[1]/preceding::a[1]</value>
      <webElementGuid>b1e39a8b-4fda-4b59-a75f-cc0d077e2791</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Show more...']/parent::*</value>
      <webElementGuid>6905348e-7f8f-407d-ac35-32bf01faa908</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/simple-blog/show/post?postId=181')]</value>
      <webElementGuid>436f83d2-0d58-40d1-b2ab-53e46cc434e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[3]/a</value>
      <webElementGuid>b999bb19-99ff-48e9-b53e-64a2d94ed151</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/simple-blog/show/post?postId=181' and (text() = 'Show more...' or . = 'Show more...')]</value>
      <webElementGuid>bf8ee6e5-7f8c-4a0b-8252-b0aef5405e21</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
