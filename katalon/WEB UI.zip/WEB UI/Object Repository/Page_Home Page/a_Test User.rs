<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Test User</name>
   <tag></tag>
   <elementGuidId>19ef3b76-3880-4dc3-a778-44bfb360cbe5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='myNavbar']/ul[2]/li/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.nav.navbar-nav.navbar-right > li > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>38aa568e-1b78-4d88-9558-7d09737e27eb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/simple-blog/show/blog-profile?userId=41</value>
      <webElementGuid>f07a0030-b94b-42b6-a73b-7b42e0b0327a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                             Test User</value>
      <webElementGuid>e52f6616-294d-4353-b449-37488be08873</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;myNavbar&quot;)/ul[@class=&quot;nav navbar-nav navbar-right&quot;]/li[1]/a[1]</value>
      <webElementGuid>d794f813-631c-486c-8ad8-b7bb4b4d1caa</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='myNavbar']/ul[2]/li/a</value>
      <webElementGuid>54c33b71-3c22-401d-bded-efb2bc37bbf9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Create New Post'])[1]/following::a[1]</value>
      <webElementGuid>e5697475-94eb-4b0e-986c-286f644fd844</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Too Simple Blog'])[1]/following::a[2]</value>
      <webElementGuid>e63c0689-0957-48bd-b379-5b62a4c825d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New Post Name For Test 1221'])[1]/preceding::a[2]</value>
      <webElementGuid>265b3316-e9f7-45f8-9dcd-d8cd911bfb89</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Test User']/parent::*</value>
      <webElementGuid>c20c9a3e-8d96-4c72-a4ea-03df0ab8ab48</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/simple-blog/show/blog-profile?userId=41')]</value>
      <webElementGuid>1a958108-6c9d-455d-aa0d-32d8b8bc85b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//ul[2]/li/a</value>
      <webElementGuid>c5d9d920-59c1-4276-a6e5-0a994ea0d09e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/simple-blog/show/blog-profile?userId=41' and (text() = '
                             Test User' or . = '
                             Test User')]</value>
      <webElementGuid>79a78482-8485-435a-911c-4d3595f7d379</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
