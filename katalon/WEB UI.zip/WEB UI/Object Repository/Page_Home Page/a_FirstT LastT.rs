<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_FirstT LastT</name>
   <tag></tag>
   <elementGuidId>94c81e85-fee5-49c2-8d94-431edb3b51e6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.nav.navbar-nav.navbar-right > li > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='myNavbar']/ul[2]/li/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>3c8030e8-229c-443f-8429-2f1ae55b3322</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/my-blog/show/profile?userId=282</value>
      <webElementGuid>e10024ff-8f75-4d34-be42-86dc141b33ae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>FirstT LastT</value>
      <webElementGuid>cbb2cc74-845b-442d-8bc9-d26d2ed45858</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;myNavbar&quot;)/ul[@class=&quot;nav navbar-nav navbar-right&quot;]/li[1]/a[1]</value>
      <webElementGuid>e3154475-ef39-4a16-b5ab-a72938393ed8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='myNavbar']/ul[2]/li/a</value>
      <webElementGuid>f841c947-b65d-435d-964d-54335375c6bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'FirstT LastT')]</value>
      <webElementGuid>c13400ee-77ec-4aba-9803-0dbc8f960f39</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Create New Post'])[1]/following::a[1]</value>
      <webElementGuid>861760c9-425c-4a7b-8c49-94dfd26a7097</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Logout'])[1]/preceding::a[1]</value>
      <webElementGuid>843e7d21-a391-4d84-96ca-3bfbff529617</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CCCC2'])[1]/preceding::a[2]</value>
      <webElementGuid>2dd044e3-1766-408b-9c43-058908449c5a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='FirstT LastT']/parent::*</value>
      <webElementGuid>63cae82e-dbb1-4a74-a17c-2b240da0196a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/my-blog/show/profile?userId=282')]</value>
      <webElementGuid>84a8bd01-2a9a-434b-a51b-02b093de2fc3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//ul[2]/li/a</value>
      <webElementGuid>9cb64a81-c42d-4994-b2ba-dfad08f48c4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/my-blog/show/profile?userId=282' and (text() = 'FirstT LastT' or . = 'FirstT LastT')]</value>
      <webElementGuid>e69a57ec-cf3f-4727-ad3a-f8cd1a915562</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
