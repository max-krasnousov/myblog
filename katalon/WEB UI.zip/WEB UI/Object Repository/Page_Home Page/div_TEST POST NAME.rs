<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_TEST POST NAME</name>
   <tag></tag>
   <elementGuidId>02400940-c8e1-4f93-860e-5c3c044c06d7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.d-grid-col</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Logout'])[1]/following::div[9]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>cc08f559-c6d1-4c4d-8b8b-753e30501a27</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>d-grid-col</value>
      <webElementGuid>f0384257-3903-4b2c-8848-39b160f61562</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>TEST POST NAME</value>
      <webElementGuid>34ae3dad-1cd0-42fe-a9f0-0087fc17f939</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;container-fluid&quot;]/div[@class=&quot;row content&quot;]/div[@class=&quot;col-xs-12&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12 col-sm-8 col-sm-offset-2&quot;]/div[@class=&quot;panel panel-default&quot;]/div[@class=&quot;panel-heading&quot;]/div[@class=&quot;d-grid&quot;]/div[@class=&quot;d-grid-col&quot;]</value>
      <webElementGuid>89cfa855-f9fa-43b0-b34a-659d19db83ed</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Logout'])[1]/following::div[9]</value>
      <webElementGuid>3e135c4a-a837-4906-8a3a-6cbc6c0462c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FirstT LastT'])[1]/following::div[9]</value>
      <webElementGuid>937a35a4-fa3a-4023-9f78-b7b91761713c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(Posted by: FirstT LastT)'])[1]/preceding::div[1]</value>
      <webElementGuid>216e0f6c-7774-460b-b82a-e1b0f569a32c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(Posted: 2023/06/08 15:15:02)'])[1]/preceding::div[2]</value>
      <webElementGuid>0e1a4c6b-4428-425a-a33c-7b6d384c28db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='TEST POST NAME']/parent::*</value>
      <webElementGuid>b655b2b0-d6b9-4021-9db6-ec279e92d837</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div/div/div/div/div</value>
      <webElementGuid>4b009d3b-ddaf-46c5-a547-6eab6dc984c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'TEST POST NAME' or . = 'TEST POST NAME')]</value>
      <webElementGuid>133b55a3-fee7-410a-9a36-8444bf5e358e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
